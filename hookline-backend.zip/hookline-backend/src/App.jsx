import React, { useState, useRef, useEffect } from "react";
import { Sparkles, Film, TrendingUp, Library, Settings, Wand2, Hash, Clock, Zap, LogOut } from "lucide-react";
import { supabase } from "./supabaseClient";

// Point this at your deployed backend URL (Render, etc.)
const BACKEND_URL = "https://YOUR-BACKEND-URL.onrender.com";

const STYLES = [
  { id: "cinematic", label: "Cinematic drama", hint: "slow push-ins, moody grade" },
  { id: "meme", label: "Meme energy", hint: "jump cuts, bold captions" },
  { id: "doc", label: "Documentary hook", hint: "talking head, b-roll" },
  { id: "asmr", label: "ASMR calm", hint: "soft focus, ambient sound" },
  { id: "chaos", label: "Fast-cut chaos", hint: "whip pans, glitch cuts" },
];

const DURATIONS = [15, 30, 60];

const CAPTION_BANK = [
  { caption: "POV: you finally found the thing that actually works", tags: ["#fyp", "#pov", "#viral"] },
  { caption: "Nobody talks about this and I don't get why", tags: ["#underrated", "#learnontiktok"] },
  { caption: "wait for it...", tags: ["#waitforit", "#hook", "#trending"] },
  { caption: "This changed how I think about it completely", tags: ["#mindblown", "#facts"] },
  { caption: "Day 1 of trying this so you don't have to", tags: ["#series", "#daily", "#relatable"] },
];

const gradients = [
  "linear-gradient(160deg,#3a1c1c,#FF5A36 60%,#1b0e0a)",
  "linear-gradient(160deg,#12211f,#0f766e 55%,#0a1412)",
  "linear-gradient(160deg,#241a30,#7c3aed 55%,#160f1d)",
  "linear-gradient(160deg,#2a2410,#C6FF3D 65%,#141207)",
  "linear-gradient(160deg,#1c1c2a,#3b82f6 55%,#0e0e16)",
];

function Sprockets({ count = 2 }) {
  return (
    <div className="flex gap-2 px-2 shrink-0">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="w-1.5 h-1.5 rounded-[2px] bg-black/40" />
      ))}
    </div>
  );
}

function FilmThumb({ item, active, onClick }) {
  return (
    <button
      onClick={onClick}
      className={`relative shrink-0 w-24 h-40 rounded-sm overflow-hidden border-2 transition-all ${
        active ? "border-[#FF5A36] scale-[1.03]" : "border-[#2A3438] hover:border-[#3E4A50]"
      }`}
      style={{ background: item.gradient }}
    >
      <div className="absolute inset-0 flex flex-col justify-between p-2">
        <span className="text-[9px] font-mono text-white/70 bg-black/30 self-start px-1 rounded-sm">
          {String(item.frame).padStart(3, "0")}
        </span>
        <div className="flex items-center gap-1 self-end bg-black/40 px-1.5 py-0.5 rounded-sm">
          <Zap className="w-2.5 h-2.5 text-[#C6FF3D]" />
          <span className="text-[9px] font-mono text-[#C6FF3D]">{item.score}</span>
        </div>
      </div>
    </button>
  );
}

function LoginScreen() {
  async function signInWithGoogle() {
    await supabase.auth.signInWithOAuth({ provider: "google" });
  }

  return (
    <div className="w-full min-h-screen bg-[#0E1416] text-[#F2F0EA] flex flex-col items-center justify-center gap-6 px-6">
      <div className="flex items-center gap-2.5">
        <div className="w-8 h-8 rounded-sm bg-[#FF5A36] flex items-center justify-center">
          <Film className="w-5 h-5 text-[#0E1416]" strokeWidth={2.5} />
        </div>
        <span className="text-2xl tracking-tight font-bold" style={{ fontFamily: "Georgia, serif" }}>
          HOOKLINE
        </span>
      </div>
      <p className="text-sm text-[#6B7680] text-center max-w-xs">
        Turn a hook into a scroll-stopping AI video. Sign in to get 3 free clips.
      </p>
      <button
        onClick={signInWithGoogle}
        className="px-5 py-3 rounded-lg bg-[#F2F0EA] text-[#0E1416] font-semibold text-sm hover:brightness-95 transition-all"
      >
        Continue with Google
      </button>
    </div>
  );
}

export default function Hookline() {
  const [session, setSession] = useState(null);
  const [credits, setCredits] = useState(null);
  const [isPremium, setIsPremium] = useState(false);
  const [prompt, setPrompt] = useState("");
  const [style, setStyle] = useState("cinematic");
  const [duration, setDuration] = useState(30);
  const [phase, setPhase] = useState("idle"); // idle | rendering | done | error
  const [renderLabel, setRenderLabel] = useState("");
  const [errorMsg, setErrorMsg] = useState("");
  const [history, setHistory] = useState([]);
  const [active, setActive] = useState(null);
  const frameCounter = useRef(1);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, s) => setSession(s));
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!session) return;
    supabase
      .from("profiles")
      .select("credits, is_premium")
      .eq("id", session.user.id)
      .single()
      .then(({ data }) => {
        if (data) {
          setCredits(data.credits);
          setIsPremium(data.is_premium);
        }
      });
  }, [session]);

  async function upgrade() {
    const res = await fetch(`${BACKEND_URL}/api/create-checkout-session`, {
      method: "POST",
      headers: { Authorization: `Bearer ${session.access_token}` },
    });
    const data = await res.json();
    if (data.url) window.location.href = data.url;
  }

  if (!session) return <LoginScreen />;

  async function generate() {
    if (!prompt.trim() || phase === "rendering" || credits <= 0) return;
    setPhase("rendering");
    setErrorMsg("");
    setRenderLabel("Sending your hook to the studio...");

    try {
      setTimeout(() => setRenderLabel("Rendering motion... this can take 1-3 minutes"), 2000);

      const res = await fetch(`${BACKEND_URL}/api/generate`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({ prompt, style, duration }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Generation failed");

      const pick = CAPTION_BANK[Math.floor(Math.random() * CAPTION_BANK.length)];
      const grad = gradients[Math.floor(Math.random() * gradients.length)];

      const item = {
        id: Date.now(),
        frame: frameCounter.current++,
        score: 60 + Math.floor(Math.random() * 39),
        prompt,
        style,
        duration,
        gradient: grad,
        videoUrl: data.videoUrl,
        caption: pick.caption,
        tags: pick.tags,
      };

      setHistory((h) => [item, ...h]);
      setActive(item);
      setCredits(data.creditsRemaining);
      setPhase("done");
    } catch (err) {
      console.error(err);
      setErrorMsg(err.message || "Something went wrong. Try again.");
      setPhase("error");
    }
  }

  const currentStyle = STYLES.find((s) => s.id === style);
  const outOfCredits = credits !== null && credits <= 0;

  return (
    <div className="w-full min-h-screen bg-[#0E1416] text-[#F2F0EA] flex flex-col font-[Inter,sans-serif]">
      <header className="flex items-center justify-between px-6 py-4 border-b border-[#1E2629]">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-sm bg-[#FF5A36] flex items-center justify-center">
            <Film className="w-4 h-4 text-[#0E1416]" strokeWidth={2.5} />
          </div>
          <span className="text-lg tracking-tight font-bold" style={{ fontFamily: "Georgia, serif" }}>
            HOOKLINE
          </span>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 text-xs font-mono text-[#C6FF3D] bg-[#1B2226] px-2.5 py-1 rounded-sm">
            <Zap className="w-3 h-3" />
            {credits === null ? "..." : `${credits} credits`}
          </div>
          {!isPremium && (
            <button
              onClick={upgrade}
              className="text-xs font-semibold bg-[#FF5A36] text-[#0E1416] px-3 py-1.5 rounded-sm hover:brightness-110 transition-all"
            >
              Remove watermark
            </button>
          )}
          <button onClick={() => supabase.auth.signOut()} className="p-2 text-[#6B7680] hover:text-[#F2F0EA]">
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </header>

      <div className="flex-1 flex flex-col lg:flex-row gap-6 p-6 overflow-hidden">
        <div className="flex-1 flex items-center justify-center min-h-[420px]">
          <div className="relative w-[240px] h-[426px] rounded-2xl border border-[#2A3438] bg-[#141B1E] overflow-hidden shadow-[0_0_0_6px_#1B2226]">
            {phase === "idle" && (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 text-center px-6">
                <Wand2 className="w-6 h-6 text-[#3E4A50]" />
                <p className="text-sm text-[#6B7680] leading-relaxed">
                  Your reel starts here. Describe the hook, pick a style, and generate.
                </p>
              </div>
            )}
            {phase === "rendering" && (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 px-6" style={{ background: "linear-gradient(160deg,#1a1210,#241812)" }}>
                <div className="w-10 h-10 rounded-full border-2 border-[#FF5A36]/30 border-t-[#FF5A36] animate-spin" />
                <p className="text-xs font-mono text-[#F2F0EA]/80 text-center">{renderLabel}</p>
              </div>
            )}
            {phase === "error" && (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 text-center px-6">
                <p className="text-sm text-[#FF5A36]">{errorMsg}</p>
                <button onClick={() => setPhase("idle")} className="text-xs text-[#6B7680] underline">
                  Try again
                </button>
              </div>
            )}
            {phase === "done" && active && (
              <div className="absolute inset-0 bg-black">
                {active.videoUrl ? (
                  <video src={active.videoUrl} className="absolute inset-0 w-full h-full object-cover" controls autoPlay loop />
                ) : (
                  <div className="absolute inset-0" style={{ background: active.gradient }} />
                )}
                {!isPremium && (
                  <div className="absolute top-3 left-3 text-[10px] font-mono text-white/60 bg-black/40 px-2 py-1 rounded-sm pointer-events-none">
                    made with HOOKLINE
                  </div>
                )}
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 to-transparent p-4 pointer-events-none">
                  <p className="text-sm font-medium leading-snug">{active.caption}</p>
                  <div className="flex flex-wrap gap-1.5 mt-1.5">
                    {active.tags.map((t) => (
                      <span key={t} className="text-[10px] font-mono text-white/70">{t}</span>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="w-full lg:w-[360px] shrink-0 flex flex-col gap-5">
          <div>
            <label className="text-[11px] font-mono uppercase tracking-wider text-[#6B7680] mb-2 block">Describe the hook</label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="A barista reveals the one mistake everyone makes with cold brew..."
              rows={4}
              className="w-full bg-[#141B1E] border border-[#2A3438] rounded-lg p-3 text-sm placeholder:text-[#4A5458] focus:outline-none focus:border-[#FF5A36] resize-none"
            />
          </div>

          <div>
            <label className="text-[11px] font-mono uppercase tracking-wider text-[#6B7680] mb-2 block">Style</label>
            <div className="flex flex-col gap-1.5">
              {STYLES.map((s) => (
                <button
                  key={s.id}
                  onClick={() => setStyle(s.id)}
                  className={`text-left px-3 py-2 rounded-md border transition-colors ${
                    style === s.id ? "border-[#FF5A36] bg-[#1B2226]" : "border-[#232C2F] hover:border-[#2A3438]"
                  }`}
                >
                  <div className="text-sm">{s.label}</div>
                  <div className="text-[11px] text-[#6B7680]">{s.hint}</div>
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-[11px] font-mono uppercase tracking-wider text-[#6B7680] mb-2 flex items-center gap-1.5">
              <Clock className="w-3 h-3" /> Duration
            </label>
            <div className="flex gap-2">
              {DURATIONS.map((d) => (
                <button
                  key={d}
                  onClick={() => setDuration(d)}
                  className={`flex-1 py-2 rounded-md text-sm font-mono border transition-colors ${
                    duration === d ? "border-[#FF5A36] text-[#FF5A36]" : "border-[#232C2F] text-[#6B7680] hover:border-[#2A3438]"
                  }`}
                >
                  {d}s
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={generate}
            disabled={!prompt.trim() || phase === "rendering" || outOfCredits}
            className="mt-1 w-full py-3 rounded-lg bg-[#FF5A36] text-[#0E1416] font-semibold text-sm flex items-center justify-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed hover:brightness-110 transition-all"
          >
            <Sparkles className="w-4 h-4" />
            {outOfCredits ? "No credits left" : phase === "rendering" ? "Rendering..." : `Generate clip — ${currentStyle.label}`}
          </button>
        </div>
      </div>

      <div className="border-t border-[#1E2629] bg-[#0B1012]">
        <div className="flex items-center gap-2 px-6 pt-3 text-[#6B7680]">
          <Hash className="w-3.5 h-3.5" />
          <span className="text-[11px] font-mono uppercase tracking-wider">Render history</span>
        </div>
        <div className="flex items-center overflow-x-auto px-4 py-3 gap-1">
          {history.length === 0 && (
            <p className="text-xs text-[#4A5458] px-2 py-8">Generated clips will line up here, like frames on a reel.</p>
          )}
          {history.map((item) => (
            <div key={item.id} className="flex items-center">
              <Sprockets />
              <FilmThumb item={item} active={active?.id === item.id} onClick={() => { setActive(item); setPhase("done"); }} />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
