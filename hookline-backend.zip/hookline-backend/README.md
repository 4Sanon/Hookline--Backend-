# Hookline — génération vidéo réelle + comptes + crédits

Tout est prêt pour demain (ou pour un déploiement manuel). Voici ce que contient ce dossier :

- `server.js` — backend qui appelle fal.ai (Kling) et vérifie/décompte les crédits
- `package.json` — dépendances du backend
- `sql/schema.sql` — à exécuter une fois dans Supabase pour créer la table des crédits
- `src/supabaseClient.js` — connexion de l'app à Supabase
- `src/App.jsx` — l'app complète : écran de connexion Google, crédits affichés, génération réelle

## Étape 1 — Créer le projet Supabase (gratuit)

1. Va sur https://supabase.com, crée un compte
2. "New project" → choisis un nom, un mot de passe de base de données (garde-le de côté), une région
3. Une fois le projet créé, va dans **Authentication → Providers → Google** et active-le
   (Supabase te guide pour connecter un compte Google Cloud — suis leurs instructions à l'écran)
4. Va dans **SQL Editor → New query**, colle le contenu de `sql/schema.sql`, clique "Run"
5. Va dans **Settings → API**, note :
   - `Project URL` (ex: `https://xxxx.supabase.co`)
   - `anon public` key
   - `service_role` key (⚠️ secrète, ne jamais l'exposer côté navigateur)

## Étape 2 — Configurer les fichiers

Dans `src/supabaseClient.js`, remplace :
- `SUPABASE_URL` par ton Project URL
- `SUPABASE_ANON_KEY` par ta clé `anon public`

Dans `src/App.jsx`, remplace `BACKEND_URL` par l'URL de ton backend une fois déployé (étape 3).

## Étape 3 — Déployer le backend (Render.com, gratuit)

1. Va sur https://render.com → "New" → "Web Service"
2. Connecte ce dossier (`server.js`, `package.json`) via un dépôt GitHub
3. Dans les variables d'environnement du service, ajoute :
   - `FAL_KEY` → ta clé fal.ai
   - `SUPABASE_URL` → ton Project URL
   - `SUPABASE_SERVICE_ROLE_KEY` → ta clé `service_role`
4. Render te donne une URL publique — colle-la dans `BACKEND_URL` (étape 2) et redéploie le frontend

## Option tout-en-un : demander à Bolt de tout faire

Colle ce message dans le chat Bolt (une fois ton compte Supabase créé et les clés en main) :

```
Ajoute l'authentification Google via Supabase et un système de crédits à mon app.

Utilise ces fichiers que je te fournis :
- server.js (backend, vérifie l'utilisateur et décompte les crédits avant chaque génération)
- src/supabaseClient.js (connexion frontend à Supabase)
- src/App.jsx (écran de connexion + affichage des crédits + génération réelle)

Variables d'environnement à configurer (je te donnerai les valeurs séparément,
ne les affiche jamais dans le code) :
- FAL_KEY
- SUPABASE_URL
- SUPABASE_SERVICE_ROLE_KEY (backend uniquement)
- Dans supabaseClient.js : SUPABASE_URL et SUPABASE_ANON_KEY (ce sont des valeurs publiques, pas secrètes)
```

## Ce que l'utilisateur voit maintenant

1. Écran de connexion Google au premier lancement
2. 3 crédits gratuits à l'inscription (visibles en haut à droite)
3. Chaque génération réussie décompte 1 crédit
4. Bouton désactivé et message "No credits left" quand les crédits sont épuisés

## Sécurité

- `SUPABASE_SERVICE_ROLE_KEY`, `FAL_KEY`, `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET` : uniquement côté backend (variables d'environnement serveur)
- `SUPABASE_ANON_KEY` : publique par design, peut être dans le code frontend sans risque

## Étape 4 — Paiement (Stripe)

1. Crée un compte sur https://stripe.com
2. Dans le Dashboard → **Product catalog**, crée un produit "Créateur" avec un prix récurrent mensuel (ex: 15€/mois)
3. Note l'ID du prix (commence par `price_...`)
4. Dans **Developers → API keys**, note ta clé secrète (`sk_...`)
5. Dans **Developers → Webhooks**, ajoute un endpoint pointant vers `https://ton-backend.onrender.com/api/stripe-webhook`, écoute les événements `checkout.session.completed` et `customer.subscription.deleted`. Note le "Signing secret" (`whsec_...`)
6. Ajoute ces variables d'environnement sur ton backend (Render) :
   - `STRIPE_SECRET_KEY`
   - `STRIPE_WEBHOOK_SECRET`
   - `STRIPE_PRICE_ID`
   - `FRONTEND_URL` (l'URL de ton app, ex: `https://react-project-setup-xwqg.bolt.host`)

Une fois configuré, le bouton "Remove watermark" dans l'app redirige vers une page de paiement Stripe sécurisée, et le compte de l'utilisateur passe automatiquement en "premium" après paiement.

**Limite actuelle à connaître** : le badge "made with HOOKLINE" est actuellement un élément visuel affiché par-dessus la vidéo dans l'interface, pas incrusté dans le fichier vidéo lui-même. Pour un vrai filigrane sur la vidéo exportée/téléchargée, il faudra ajouter un traitement vidéo côté serveur (ex: avec ffmpeg) — utile à prévoir avant le vrai lancement commercial.

## Documents légaux (dossier `legal/`)

- `mentions-legales.md`, `cgu.md`, `politique-confidentialite.md` — des modèles de base à compléter avec tes informations réelles (SIRET, adresse, etc.)
- ⚠️ Ce sont des points de départ, pas un conseil juridique définitif. Fais-les relire par un professionnel avant le lancement, surtout parce que le service traite des paiements et des données personnelles (RGPD)
- Une fois complétés, demande à Bolt de les ajouter comme pages de l'app (ex: `/mentions-legales`, `/cgu`, `/confidentialite`), avec des liens en pied de page
