-- Run this in the Supabase SQL editor (Dashboard → SQL Editor → New query)

create table if not exists public.profiles (
  id uuid references auth.users on delete cascade primary key,
  email text,
  credits integer not null default 3,
  is_premium boolean not null default false,
  stripe_customer_id text,
  created_at timestamp with time zone default now()
);

alter table public.profiles enable row level security;

create policy "Users can view their own profile"
  on public.profiles for select
  using (auth.uid() = id);

create policy "Users can update their own profile"
  on public.profiles for update
  using (auth.uid() = id);

-- Automatically create a profile row (with 3 free credits) whenever someone signs up
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email, credits)
  values (new.id, new.email, 3);
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();
