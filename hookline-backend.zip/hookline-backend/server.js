import express from "express";
import cors from "cors";
import { fal } from "@fal-ai/client";
import { createClient } from "@supabase/supabase-js";
import Stripe from "stripe";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

const app = express();
app.use(cors());

// The Stripe webhook needs the raw request body to verify the signature,
// so it must be registered BEFORE express.json() and use its own raw parser.
app.post("/api/stripe-webhook", express.raw({ type: "application/json" }), async (req, res) => {
  let event;
  try {
    event = stripe.webhooks.constructEvent(
      req.body,
      req.headers["stripe-signature"],
      process.env.STRIPE_WEBHOOK_SECRET
    );
  } catch (err) {
    console.error("Webhook signature verification failed:", err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  try {
    if (event.type === "checkout.session.completed") {
      const session = event.data.object;
      const userId = session.client_reference_id;
      if (userId) {
        await supabaseAdmin
          .from("profiles")
          .update({ is_premium: true, stripe_customer_id: session.customer })
          .eq("id", userId);
      }
    }

    if (event.type === "customer.subscription.deleted") {
      const subscription = event.data.object;
      await supabaseAdmin
        .from("profiles")
        .update({ is_premium: false })
        .eq("stripe_customer_id", subscription.customer);
    }

    res.json({ received: true });
  } catch (err) {
    console.error("Webhook handling error:", err);
    res.status(500).json({ error: "Webhook handler failed" });
  }
});

app.use(express.json());

// Secrets — set these as environment variables, never hardcode them.
fal.config({ credentials: process.env.FAL_KEY });

// The service role key can bypass row-level security, so it must ONLY
// ever be used here on the server, never sent to the browser.
const supabaseAdmin = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

const STYLE_MODIFIERS = {
  cinematic: "cinematic lighting, moody color grade, slow camera push-in, shallow depth of field",
  meme: "bright flat lighting, fast jump cuts, bold on-screen energy, punchy colors",
  doc: "natural lighting, handheld documentary feel, realistic setting",
  asmr: "soft diffused lighting, close-up detail, calm gentle motion",
  chaos: "high contrast lighting, whip pan camera movement, glitch transitions, fast pace",
};

async function getUserFromRequest(req) {
  const authHeader = req.headers.authorization || "";
  const token = authHeader.replace("Bearer ", "");
  if (!token) return null;
  const { data, error } = await supabaseAdmin.auth.getUser(token);
  if (error) return null;
  return data.user;
}

app.post("/api/create-checkout-session", async (req, res) => {
  try {
    const user = await getUserFromRequest(req);
    if (!user) {
      return res.status(401).json({ error: "Not signed in" });
    }

    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      customer_email: user.email,
      client_reference_id: user.id,
      line_items: [
        {
          price: process.env.STRIPE_PRICE_ID, // the "Créateur" plan price, created in Stripe Dashboard
          quantity: 1,
        },
      ],
      success_url: `${process.env.FRONTEND_URL}?upgraded=true`,
      cancel_url: `${process.env.FRONTEND_URL}?upgraded=false`,
    });

    res.json({ url: session.url });
  } catch (err) {
    console.error("Checkout session error:", err);
    res.status(500).json({ error: "Could not start checkout" });
  }
});

app.post("/api/generate", async (req, res) => {
  try {
    const user = await getUserFromRequest(req);
    if (!user) {
      return res.status(401).json({ error: "Not signed in" });
    }

    const { prompt, style, duration } = req.body;
    if (!prompt || typeof prompt !== "string" || !prompt.trim()) {
      return res.status(400).json({ error: "Missing prompt" });
    }

    // Check credits
    const { data: profile, error: profileErr } = await supabaseAdmin
      .from("profiles")
      .select("credits")
      .eq("id", user.id)
      .single();

    if (profileErr || !profile) {
      return res.status(404).json({ error: "Profile not found" });
    }
    if (profile.credits <= 0) {
      return res.status(402).json({ error: "No credits left" });
    }

    // Generate the video
    const styleText = STYLE_MODIFIERS[style] || STYLE_MODIFIERS.cinematic;
    const enrichedPrompt = `${prompt.trim()}. Style: ${styleText}.`;

    const result = await fal.subscribe("fal-ai/kling-video/v1.6/standard/text-to-video", {
      input: { prompt: enrichedPrompt },
      logs: false,
    });

    const videoUrl = result?.data?.video?.url;
    if (!videoUrl) {
      return res.status(502).json({ error: "No video returned by the provider" });
    }

    // Deduct one credit only after a successful generation
    await supabaseAdmin
      .from("profiles")
      .update({ credits: profile.credits - 1 })
      .eq("id", user.id);

    res.json({ videoUrl, requestId: result.requestId, creditsRemaining: profile.credits - 1 });
  } catch (err) {
    console.error("Generation error:", err);
    res.status(500).json({ error: "Video generation failed" });
  }
});

app.get("/health", (req, res) => res.json({ ok: true }));

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`Hookline backend running on port ${PORT}`));
