# Politique de confidentialité

*Modèle de base à compléter et à faire valider par un professionnel du droit avant mise en ligne, en particulier dans le cadre du RGPD.*

Dernière mise à jour : [date]

## 1. Responsable du traitement

[Nom / raison sociale], [adresse], [email de contact]

## 2. Données collectées

- **Données de compte** : email, identifiant Google (via Supabase Auth)
- **Données d'utilisation** : prompts saisis, historique des vidéos générées, nombre de crédits
- **Données de paiement** : traitées directement par Stripe ; Hookline ne stocke aucune donnée bancaire, uniquement l'identifiant client Stripe

## 3. Finalités du traitement

- Fournir le service de génération vidéo
- Gérer les comptes utilisateurs et les crédits
- Traiter les paiements et abonnements
- Améliorer le service

## 4. Sous-traitants et destinataires des données

- **Supabase** : hébergement de la base de données et authentification
- **fal.ai (et modèles d'IA tiers, ex: Kling)** : traitement des prompts pour générer les vidéos
- **Stripe** : traitement des paiements
- [Ajouter tout autre prestataire utilisé, ex: hébergeur frontend]

Les prompts et éventuelles images fournies par l'utilisateur sont transmis à ces prestataires tiers dans le seul but de générer la vidéo demandée.

## 5. Durée de conservation

[À définir — ex: les données de compte sont conservées tant que le compte est actif, puis supprimées dans un délai de X mois après suppression du compte]

## 6. Droits de l'utilisateur (RGPD)

Conformément au RGPD, l'utilisateur dispose d'un droit d'accès, de rectification, d'effacement, de limitation et de portabilité de ses données, ainsi que d'un droit d'opposition. Pour exercer ces droits : [email de contact]

## 7. Sécurité

Les données sont stockées de façon sécurisée via Supabase. Les clés d'accès aux services tiers (fal.ai, Stripe) sont conservées côté serveur et ne sont jamais exposées publiquement.

## 8. Cookies

[À compléter selon les outils d'analytics ou de suivi éventuellement ajoutés au site]

## 9. Contact

Pour toute question relative à cette politique : [Email de contact]
