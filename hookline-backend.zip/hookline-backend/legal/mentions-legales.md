# Mentions légales

*Modèle de base à compléter et à faire valider par un professionnel du droit avant mise en ligne, en particulier une fois les paiements activés.*

## Éditeur du site

- Nom / raison sociale : [À compléter — ex: Hookline SASU, ou ton nom si auto-entrepreneur]
- Forme juridique : [À compléter — auto-entrepreneur / SASU / SAS...]
- Adresse du siège social : [À compléter]
- Numéro SIRET : [À compléter une fois la structure créée]
- Capital social (si société) : [À compléter]
- Directeur de la publication : [Ton nom]
- Contact : [Email de contact]

## Hébergement

- Hébergeur du site : [Nom de l'hébergeur, ex: Vercel Inc. / Render / Netlify]
- Adresse de l'hébergeur : [À compléter selon le fournisseur choisi]

## Propriété intellectuelle

L'ensemble des contenus présents sur Hookline (textes, logo, interface, éléments graphiques) est protégé par le droit d'auteur, sauf mention contraire. Toute reproduction non autorisée est interdite.

Les vidéos générées par l'utilisateur via l'outil restent sa propriété, sous réserve des conditions d'utilisation des modèles d'IA tiers utilisés pour la génération (voir CGU, article sur les contenus générés).

## Données personnelles

Voir la [Politique de confidentialité](./politique-confidentialite.md) pour le détail du traitement des données.

## Contact

Pour toute question relative à ces mentions légales : [Email de contact]
