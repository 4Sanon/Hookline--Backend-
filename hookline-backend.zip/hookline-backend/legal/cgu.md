# Conditions Générales d'Utilisation (CGU)

*Modèle de base à compléter et à faire valider par un professionnel du droit avant mise en ligne, en particulier une fois les paiements activés.*

Dernière mise à jour : [date]

## 1. Objet

Les présentes CGU régissent l'utilisation du service Hookline, une application permettant de générer des vidéos courtes à l'aide de modèles d'intelligence artificielle tiers.

## 2. Acceptation des CGU

En créant un compte ou en utilisant Hookline, l'utilisateur accepte sans réserve les présentes CGU.

## 3. Description du service

Hookline permet à l'utilisateur de décrire un concept de vidéo ("hook"), de choisir un style, et de générer un clip vidéo via des modèles d'IA tiers (notamment des modèles de génération vidéo fournis par des prestataires externes).

## 4. Compte utilisateur

L'utilisateur doit créer un compte pour utiliser le service. Il est responsable de la confidentialité de ses identifiants de connexion.

## 5. Crédits et abonnement

- Chaque nouvel utilisateur reçoit un nombre défini de crédits gratuits à l'inscription.
- Chaque génération de vidéo consomme un crédit.
- Un abonnement payant permet d'obtenir des fonctionnalités supplémentaires (suppression du filigrane, crédits additionnels, résolution supérieure).
- Les paiements sont traités par un prestataire tiers (Stripe). Hookline ne stocke aucune donnée bancaire.
- [À compléter : politique de remboursement, modalités de résiliation d'abonnement]

## 6. Contenus générés par l'IA

- Les vidéos sont générées par des modèles d'intelligence artificielle tiers. Hookline ne garantit pas l'exactitude, la qualité ou l'absence d'erreur des contenus générés.
- L'utilisateur s'engage à ne pas utiliser le service pour générer des contenus illégaux, diffamatoires, trompeurs, portant atteinte aux droits d'un tiers, ou visant à usurper l'identité d'une personne réelle sans son consentement.
- L'utilisation de l'image ou de la voix d'une personne réelle sans son autorisation est strictement interdite.
- Hookline se réserve le droit de suspendre tout compte utilisé en violation de ces règles.

## 7. Propriété des contenus générés

Sous réserve du respect des présentes CGU et des conditions d'utilisation des prestataires d'IA tiers, l'utilisateur conserve les droits sur les vidéos qu'il génère et peut les utiliser, y compris commercialement.

## 8. Responsabilité

Hookline agit comme intermédiaire technique entre l'utilisateur et des prestataires d'IA tiers. Hookline ne saurait être tenu responsable :
- des interruptions de service liées à ces prestataires tiers
- du contenu généré par ces modèles d'IA
- de tout dommage indirect résultant de l'utilisation du service

## 9. Résiliation

L'utilisateur peut supprimer son compte à tout moment. Hookline se réserve le droit de suspendre ou résilier un compte en cas de violation des présentes CGU.

## 10. Droit applicable

Les présentes CGU sont soumises au droit [pays à préciser, ex: français]. Tout litige relève des tribunaux compétents [ville/juridiction à préciser].

## 11. Contact

Pour toute question : [Email de contact]
